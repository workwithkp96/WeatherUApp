package com.weatherapp.WeatherUapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WeatherUappApplicationTests {

	@Test
	void contextLoads() {
	}

}
